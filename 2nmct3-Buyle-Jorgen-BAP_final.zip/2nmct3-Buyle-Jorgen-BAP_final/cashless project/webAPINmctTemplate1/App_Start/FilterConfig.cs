﻿using System.Web;
using System.Web.Mvc;

namespace webAPINmctTemplate1
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
