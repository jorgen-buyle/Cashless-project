﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cashless_project_klanten.viewmodel
{
    class OpladenVM
    {
        public string Name
        {
            get { return "opladen van kaart"; }
        }
    }
}
