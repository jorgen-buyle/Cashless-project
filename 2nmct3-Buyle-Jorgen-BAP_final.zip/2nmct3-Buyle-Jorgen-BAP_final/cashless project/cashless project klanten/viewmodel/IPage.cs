﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cashless_project_klanten.viewmodel
{
    interface IPage
    {
        string Name { get; }
    }
}
